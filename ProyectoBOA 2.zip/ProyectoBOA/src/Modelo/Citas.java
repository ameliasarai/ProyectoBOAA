
package Modelo;

public class Citas {
  String Nombre;
  String Identificacion;
  String Edad;
  String Celular;
  String Sexo;
   String Expediente;
   String TipoCita;
   String Medico;
    String Especialidad;
    String NumeroConsultorio;
    String FechaCita;

    public Citas(String Nombre, String Identificacion, String Edad, String Celular, String Sexo, String Expediente, String TipoCita, String Medico, String Especialidad, String NumeroConsultorio, String FechaCita) {
        this.Nombre = Nombre;
        this.Identificacion = Identificacion;
        this.Edad = Edad;
        this.Celular = Celular;
        this.Sexo = Sexo;
        this.Expediente = Expediente;
        this.TipoCita = TipoCita;
        this.Medico = Medico;
        this.Especialidad = Especialidad;
        this.NumeroConsultorio = NumeroConsultorio;
        this.FechaCita = FechaCita;
    }
public Citas(){
    
}
    
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getIdentificacion() {
        return Identificacion;
    }

    public void setIdentificacion(String Identificacion) {
        this.Identificacion = Identificacion;
    }

    public String getEdad() {
        return Edad;
    }

    public void setEdad(String Edad) {
        this.Edad = Edad;
    }

    public String getCelular() {
        return Celular;
    }

    public void setCelular(String Celular) {
        this.Celular = Celular;
    }

    public String getSexo() {
        return Sexo;
    }

    public void setSexo(String Sexo) {
        this.Sexo = Sexo;
    }

    public String getExpediente() {
        return Expediente;
    }

    public void setExpediente(String Expediente) {
        this.Expediente = Expediente;
    }

    public String getTipoCita() {
        return TipoCita;
    }

    public void setTipoCita(String TipoCita) {
        this.TipoCita = TipoCita;
    }

    public String getMedico() {
        return Medico;
    }

    public void setMedico(String Medico) {
        this.Medico = Medico;
    }

    public String getEspecialidad() {
        return Especialidad;
    }

    public void setEspecialidad(String Especialidad) {
        this.Especialidad = Especialidad;
    }

    public String getNumeroConsultorio() {
        return NumeroConsultorio;
    }

    public void setNumeroConsultorio(String NumeroConsultorio) {
        this.NumeroConsultorio = NumeroConsultorio;
    }

    public String getFechaCita() {
        return FechaCita;
    }

    public void setFechaCita(String FechaCita) {
        this.FechaCita = FechaCita;
    }
    public Object[] toArray(){
      Object [] obj = new Object [11];
      obj[0] = Nombre;
      obj[1]= Identificacion;
      obj[2] = Edad;
      obj[3]=Celular;
      obj[4]=Sexo;
       obj[5]=Expediente;        
        obj[6] = TipoCita;      
         obj[7]= Medico;
          obj[8]=Especialidad;
            obj[9]=NumeroConsultorio;
             obj[10]=FechaCita;
   
             return obj;
    }
    
}
