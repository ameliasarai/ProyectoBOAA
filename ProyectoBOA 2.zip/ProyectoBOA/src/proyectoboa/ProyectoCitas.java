
package proyectoboa;

import Modelo.Citas;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class ProyectoCitas extends javax.swing.JInternalFrame {
    private DefaultTableModel tblModel;
private final String[] header ={
    "Nombres",
    "Identidicacion",
    "Edad",
    "Celular",
    "Sexo",
    "Expediente",
    "Tipo de cita",
    "Medico",
    "Especialidad",
    "Numero de consultorio",
        "Fecha de cita",
};
   
    public ProyectoCitas() {
        initComponents();
   initTable();
    }
    private void limpiarCampos(){
     txtNombres.setText("");
     txtIdentificacion.setText("");
     txtEdad.setText("");
     txtCelular.setText("");
     txtSexo.setToolTipText("");
     txtExpediente.setText("");
     txtTipoCita.setToolTipText("");
     txtMedico.setText("");
     txtEspecialidad.setToolTipText("");
     txtNumeroConsulta.setToolTipText("");
     txtFechaCita.setToolTipText("");
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel9 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtNombres = new javax.swing.JTextField();
        txtIdentificacion = new javax.swing.JFormattedTextField();
        txtEdad = new javax.swing.JFormattedTextField();
        txtCelular = new javax.swing.JFormattedTextField();
        txtSexo = new javax.swing.JComboBox<>();
        txtExpediente = new javax.swing.JFormattedTextField();
        txtTipoCita = new javax.swing.JComboBox<>();
        txtNumeroConsulta = new javax.swing.JComboBox<>();
        txtMedico = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtFechaCita = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        txtEspecialidad = new javax.swing.JComboBox<>();
        jButtonAgregar = new javax.swing.JButton();
        jButtonEditar = new javax.swing.JButton();
        jButtonEliminar = new javax.swing.JButton();
        jButtonEliminarTodo = new javax.swing.JButton();
        txtActualizar = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablaRegistro = new javax.swing.JTable();

        jLabel9.setText("Clinica:");

        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 0, 153));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Datos del paciente ", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 18), new java.awt.Color(0, 51, 102))); // NOI18N

        jLabel1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel1.setText("Nombre y Apellido:");

        jLabel2.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel2.setText("Identificación:");

        jLabel3.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel3.setText("Edad:");

        jLabel4.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel4.setText("Celular:");

        jLabel5.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel5.setText("Sexo:");

        jLabel6.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel6.setText("Expediente:");

        jLabel7.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel7.setText("Tipo de Cita: ");

        jLabel8.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel8.setText("Numero de Consultorio:");

        jLabel10.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel10.setText("Médico");

        jLabel11.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel11.setText("Especialidad ");

        try {
            txtIdentificacion.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###-#####-####U")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        try {
            txtEdad.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        try {
            txtCelular.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        txtSexo.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txtSexo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Femenino ", "Masculino" }));

        try {
            txtExpediente.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###-####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        txtTipoCita.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txtTipoCita.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Urgente ", "No Urgente " }));
        txtTipoCita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTipoCitaActionPerformed(evt);
            }
        });

        txtNumeroConsulta.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txtNumeroConsulta.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", " " }));

        jLabel12.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel12.setText("Fecha de Cita Médica ");

        txtFechaCita.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txtFechaCita.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Lunes 06 de Octubre 2025", "Miércoles 22 de Octubre 2025", "Jueves 06 de Noviembre 2025", "Martes 18 de Noviembre 2025", " " }));
        txtFechaCita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFechaCitaActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel13.setText("Fechas Disponibles ");

        txtEspecialidad.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txtEspecialidad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Medicina Interna", "Ginecología Obstetricia", "Pediatría ", "Neumología ", "Psiquiatría " }));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtIdentificacion)
                    .addComponent(txtCelular)
                    .addComponent(txtEdad)
                    .addComponent(txtSexo, 0, 161, Short.MAX_VALUE)
                    .addComponent(txtNombres))
                .addGap(35, 35, 35)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNumeroConsulta, 0, 114, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addGap(42, 42, 42)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtExpediente)
                            .addComponent(txtTipoCita, 0, 161, Short.MAX_VALUE)
                            .addComponent(txtMedico)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtEspecialidad, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(133, 133, 133)
                        .addComponent(txtFechaCita, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(141, 141, 141)
                        .addComponent(jLabel12)))
                .addContainerGap(186, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel13)
                .addGap(247, 247, 247))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel6)
                    .addComponent(txtNombres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtExpediente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel7)
                    .addComponent(txtIdentificacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTipoCita, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtFechaCita, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtEdad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(txtMedico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtCelular, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(txtEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtSexo, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(txtNumeroConsulta, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 1070, 350));

        jButtonAgregar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jButtonAgregar.setForeground(new java.awt.Color(0, 51, 102));
        jButtonAgregar.setText("Agregar");
        jButtonAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAgregarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonAgregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 420, 136, -1));

        jButtonEditar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jButtonEditar.setForeground(new java.awt.Color(0, 51, 102));
        jButtonEditar.setText("Editar");
        jButtonEditar.setPreferredSize(new java.awt.Dimension(87, 24));
        jButtonEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonEditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 420, 136, -1));

        jButtonEliminar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jButtonEliminar.setForeground(new java.awt.Color(0, 51, 102));
        jButtonEliminar.setText("Eliminar");
        jButtonEliminar.setPreferredSize(new java.awt.Dimension(87, 24));
        jButtonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEliminarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 420, 136, -1));

        jButtonEliminarTodo.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jButtonEliminarTodo.setForeground(new java.awt.Color(0, 51, 102));
        jButtonEliminarTodo.setText("Eliminar Todo");
        jButtonEliminarTodo.setPreferredSize(new java.awt.Dimension(87, 24));
        jButtonEliminarTodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEliminarTodoActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonEliminarTodo, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 420, 136, -1));

        txtActualizar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        txtActualizar.setForeground(new java.awt.Color(0, 51, 102));
        txtActualizar.setText("Actualizar");
        txtActualizar.setPreferredSize(new java.awt.Dimension(87, 24));
        txtActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtActualizarActionPerformed(evt);
            }
        });
        jPanel1.add(txtActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 420, 136, -1));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jTablaRegistro.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "", "", "", "", "", "", "", "", "", "", ""
            }
        ));
        jScrollPane1.setViewportView(jTablaRegistro);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1070, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 460, 1070, 330));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -40, 1080, 810));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtTipoCitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTipoCitaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTipoCitaActionPerformed

    private void txtFechaCitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFechaCitaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFechaCitaActionPerformed

    private void jButtonAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAgregarActionPerformed
       String Nombre = txtNombres.getText();
       String Identificacion = txtIdentificacion.getText();
       String Edad=txtEdad.getText();
       String Celular = txtCelular.getText();
       String Sexo = (String) txtSexo.getSelectedItem();
       String Expediente = txtExpediente.getText();
       String TipoCita = (String) txtTipoCita.getSelectedItem();
       String Medico = txtMedico.getText();
       String Especialidad=(String) txtEspecialidad.getSelectedItem();
       String NumeroConsultorio=(String) txtNumeroConsulta.getSelectedItem();
       String FechaCita =(String) txtFechaCita.getSelectedItem();
       
       Citas p = new Citas(Nombre, Identificacion,Edad,Celular,Sexo,Expediente,TipoCita, Medico,Especialidad,NumeroConsultorio,FechaCita);
     tblModel.addRow(p.toArray());
     txtNombres.setText("");
     txtIdentificacion.setText("");
     txtEdad.setText("");
     txtCelular.setText("");
     txtSexo.setToolTipText("");
     txtExpediente.setText("");
     txtTipoCita.setToolTipText("");
     txtMedico.setText("");
     txtEspecialidad.setToolTipText("");
     txtNumeroConsulta.setToolTipText("");
     txtFechaCita.setToolTipText("");
   
     JOptionPane.showMessageDialog(null, "Datos Agregados Correctamente");
    }//GEN-LAST:event_jButtonAgregarActionPerformed

    private void txtActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtActualizarActionPerformed
    
    }//GEN-LAST:event_txtActualizarActionPerformed

    private void jButtonEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEditarActionPerformed
       
    
      String Nombre = txtNombres.getText();
       String Identificacion = txtIdentificacion.getText();
       String Edad=txtEdad.getText();
       String Celular = txtCelular.getText();
       String Sexo = (String) txtSexo.getSelectedItem();
       String Expediente = txtExpediente.getText();
       String TipoCita = (String) txtTipoCita.getSelectedItem();
       String Medico = txtMedico.getText();
       String Especialidad=(String) txtEspecialidad.getSelectedItem();
       String NumeroConsultorio=(String) txtNumeroConsulta.getSelectedItem();
       String FechaCita =(String) txtFechaCita.getSelectedItem(); 
       
       int fila = jTablaRegistro.getSelectedRow();
       if (fila== -1){
           JOptionPane.showMessageDialog(rootPane, 
                   "Seleccione un Registro de la Tabla");
}else{
       
       
        Citas p = new Citas(Nombre, Identificacion,Edad,Celular,Sexo,Expediente,TipoCita, Medico,Especialidad,NumeroConsultorio,FechaCita);
        tblModel.setValueAt(p.getNombre(), fila, 0);
        tblModel.setValueAt(p.getIdentificacion(), fila, 1);
        tblModel.setValueAt(p.getEdad(),fila, 2);
        tblModel.setValueAt(p.getCelular(), fila, 3);
        tblModel.setValueAt(p.getSexo(), fila, 4);
        tblModel.setValueAt(p.getExpediente(), fila, 5);
        tblModel.setValueAt(p.getTipoCita(), fila, 6);
        tblModel.setValueAt(p.getMedico(), fila, 7);
        tblModel.setValueAt(p.getEspecialidad(), fila, 8);
        tblModel.setValueAt(p.getNumeroConsultorio(), fila, 9);
        tblModel.setValueAt(p.getFechaCita(), fila, 10);
       }
    }//GEN-LAST:event_jButtonEditarActionPerformed

    private void jButtonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEliminarActionPerformed
int fila = this.jTablaRegistro.getSelectedRow();
if (fila == -1){
    JOptionPane.showMessageDialog(rootPane, 
            "Seleccione un Registro de la Tabla");
}else{
    JDialog.setDefaultLookAndFeelDecorated(true);
    int resp = JOptionPane.showConfirmDialog(null, "Esta Seguro de Eliminar?", "Eliminando...",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
    if (resp == JOptionPane.YES_OPTION){
        tblModel.removeRow(fila);
        limpiarCampos();
    }
}
    }//GEN-LAST:event_jButtonEliminarActionPerformed

    private void jButtonEliminarTodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEliminarTodoActionPerformed
        int filas=jTablaRegistro.getRowCount();
        for (int i = filas -1; i>=0;i--){
            tblModel.removeRow(i);
        }
    }//GEN-LAST:event_jButtonEliminarTodoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAgregar;
    private javax.swing.JButton jButtonEditar;
    private javax.swing.JButton jButtonEliminar;
    private javax.swing.JButton jButtonEliminarTodo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablaRegistro;
    private javax.swing.JButton txtActualizar;
    private javax.swing.JFormattedTextField txtCelular;
    private javax.swing.JFormattedTextField txtEdad;
    private javax.swing.JComboBox<String> txtEspecialidad;
    private javax.swing.JFormattedTextField txtExpediente;
    private javax.swing.JComboBox<String> txtFechaCita;
    private javax.swing.JFormattedTextField txtIdentificacion;
    private javax.swing.JTextField txtMedico;
    private javax.swing.JTextField txtNombres;
    private javax.swing.JComboBox<String> txtNumeroConsulta;
    private javax.swing.JComboBox<String> txtSexo;
    private javax.swing.JComboBox<String> txtTipoCita;
    // End of variables declaration//GEN-END:variables

    private void initTable() {
      tblModel=new DefaultTableModel(header,0);
      jTablaRegistro.setModel(tblModel);
      
    }
}
